#node.py

class Node:
    def __init__(self,entry):
        self.entry = entry
        self.next = None
