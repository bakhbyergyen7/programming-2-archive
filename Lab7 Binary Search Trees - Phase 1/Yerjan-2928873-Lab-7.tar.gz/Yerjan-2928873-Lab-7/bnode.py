#bnode.py

class BNode:
    def __init__(self,entry):
        self.entry = entry
        self.left = None
        self.right = None